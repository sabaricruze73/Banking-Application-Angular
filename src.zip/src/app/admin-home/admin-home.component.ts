import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
})
export class AdminHomeComponent implements OnInit {
  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const cookie = document.cookie;
    if (!cookie || cookie.trim() === '') {
      this.router.navigate(['/login']);
    }
  }

  fetchCustomers() {
    this.http
      .get('http://localhost:8080/BankingZoho/html/User', {
        responseType: 'text',
      })
      .subscribe((response) => {
        document.getElementById('div')!.innerHTML = response;
      });
  }

  fetchAlltransactions() {
    this.http
      .get('http://localhost:8080/BankingZoho/html/Transaction', {
        responseType: 'text',
      })
      .subscribe((response) => {
        document.getElementById('div')!.innerHTML = response;
        document.getElementById('filterTransactionInput')!.style.display =
          'block';
      });
  }

  filterTransaction() {
    const filterValue = (
      document.getElementById('transactionFilter') as HTMLInputElement
    ).value;
    this.http
      .get('http://localhost:8080/BankingZoho/html/Transaction', {
        params: { amount: filterValue },
        responseType: 'text',
      })
      .subscribe((response) => {
        document.getElementById('div')!.innerHTML = response;
        document.getElementById('filterTransactionInput')!.style.display =
          'block';
      });
  }

  fetchAllPasswordResetRequests() {
    this.http
      .get(
        'http://localhost:8080/BankingZoho/html/User?mode=listPasswordResetRequests',
        { responseType: 'text' }
      )
      .subscribe((response) => {
        const result = response.slice(1, response.length - 1);
        const userArray = result
          .split(',')
          .map((user) => user.trim().replace(/\]$/, ''));
        const tableContainer = document.getElementById('div');
        const mainContainer = document.getElementById('container');
        mainContainer!.style.display = 'none';

        const table = document.createElement('table');
        const headerRow = table.insertRow();
        const usernameHeader = headerRow.insertCell(0);
        usernameHeader.textContent = 'Username';
        const resetHeader = headerRow.insertCell(1);
        resetHeader.textContent = 'Action';

        userArray.forEach((username) => {
          const row = table.insertRow();
          const usernameCell = row.insertCell(0);
          usernameCell.textContent = username;

          const buttonCell = row.insertCell(1);
          const resetButton = document.createElement('button');
          resetButton.textContent = 'Reset';
          resetButton.onclick = () => this.resetPassword(username);
          buttonCell.appendChild(resetButton);
        });

        tableContainer!.appendChild(table);
      });
  }

  resetPassword(username: string) {
    const data = new HttpParams().set('userName', username);
    this.http
      .post(
        'http://localhost:8080/BankingZoho/html/User?mode=resetPassword',
        data,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      )
      .subscribe((response: any) => {
        document.getElementById('responseTxt')!.innerHTML = response;
      });
  }

  fetchPlayGameRequests() {
    this.http
      .get(
        'http://localhost:8080/BankingZoho/html/User?mode=listPlayGameRequests',
        { responseType: 'text' }
      )
      .subscribe((response) => {
        const result = response.slice(1, response.length - 1);
        const userArray = result
          .split(',')
          .map((user) => user.trim().replace(/\]$/, ''));
        const uniqueUsers = [...new Set(userArray)];
        const tableContainer = document.getElementById('div');
        const mainContainer = document.getElementById('container');
        mainContainer!.style.display = 'none';

        const table = document.createElement('table');
        const headerRow = table.insertRow();
        const usernameHeader = headerRow.insertCell(0);
        usernameHeader.textContent = 'Username';
        const resetHeader = headerRow.insertCell(1);
        resetHeader.textContent = 'Action';

        uniqueUsers.forEach((username) => {
          const row = table.insertRow();
          const usernameCell = row.insertCell(0);
          usernameCell.textContent = username;

          const buttonCell = row.insertCell(1);
          const acceptButton = document.createElement('button');
          acceptButton.textContent = 'Accept';
          acceptButton.onclick = () => this.acceptGame(username);
          buttonCell.appendChild(acceptButton);
        });

        tableContainer!.appendChild(table);
      });
  }

  acceptGame(username: string) {
    const data = new HttpParams().set('userName', username);
    this.http
      .post(
        'http://localhost:8080/BankingZoho/html/User?mode=acceptGame',
        data,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      )
      .subscribe((response: any) => {
        document.getElementById('responseTxt')!.innerHTML = response;
      });
  }

  showFriendsGroup() {
    this.http
      .get('http://localhost:8080/BankingZoho/html/Friend?mode=friendsGroup', {
        responseType: 'text',
      })
      .subscribe((response) => {
        const mainContainer = document.getElementById('container');
        mainContainer!.style.display = 'none';
        document.getElementById('div')!.innerHTML = response;
      });
  }

  navigateTo(url: string) {
    window.location.href = url;
  }

  logout(): void {
    document.cookie =
      'userName=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/';
    this.router.navigate(['/login']);
  }
}
