import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css'],
})
export class UserHomeComponent implements OnInit {
  onlineTransactionStatus: string = '';
  userDetails: any;
  accountTypeButton: boolean = false;
  transactionStatus: string = '';
  addFriendShow = false;
  addFriendButtonShow = false;
  responseMessage: string = '';
  chatInput: string = '';
  NickNameInput: string = '';
  divHtml: string = '';
  isTransactionFetched: boolean = false;
  NickName: string = '';
  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const cookie = document.cookie;
    if (!cookie || cookie.trim() === '') {
      this.router.navigate(['/login']);
    }
    this.fetchAccountDetails();
    this.fetchOnlineTransactions();
  }

  async fetchAccountDetails() {
    try {
      const response = await this.http
        .get('http://localhost:8080/BankingZoho/html/User?mode=selfAccount', {
          responseType: 'text',
        })
        .toPromise();
      const accountType = response;
      console.log(accountType);
      this.accountTypeButton = accountType === 'Current';
    } catch (error) {
      console.error('Error fetching account details', error);
    }
  }

  fetchOnlineTransactions() {
    this.http
      .get<string>(
        'http://localhost:8080/BankingZoho/html/User?mode=onlineTransaction',
        {
          responseType: 'text' as 'json',
        }
      )
      .subscribe({
        next: (response) => {
          this.onlineTransactionStatus = response.trim().toLowerCase();
          this.transactionStatus =
            this.onlineTransactionStatus === 'enabled' ? 'Disable' : 'Enable';

          this.cdr.detectChanges();
        },
        error: (error) => {
          console.error('Error fetching online transactions:', error);
        },
      });
  }

  async changeOnlineTransactionStatus() {
    try {
      const data = new HttpParams().set('status', this.transactionStatus);
      await this.http
        .post(
          'http://localhost:8080/BankingZoho/html/User?mode=changeTransactionStatus',
          data,
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        )
        .toPromise();

      console.log('Status successfully updated');

      this.onlineTransactionStatus =
        this.transactionStatus.toLowerCase() === 'disable'
          ? 'disabled'
          : 'enabled';

      this.transactionStatus =
        this.onlineTransactionStatus === 'enabled' ? 'Disable' : 'Enable';

      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error changing transaction status:', error);
    }
  }

  fetchTransactions() {
    this.http
      .get('http://localhost:8080/BankingZoho/html/Transaction?mode=self', {
        responseType: 'text',
      })
      .subscribe(
        (response) => {
          this.divHtml = response;
          this.isTransactionFetched = true;
        },
        (error) => {
          console.error('Error fetching transactions', error);
        }
      );
  }

  async requestForGame() {
    try {
      const response = await this.http
        .get(
          'http://localhost:8080/BankingZoho/html/User?mode=requestForGame',
          { observe: 'response' }
        )
        .toPromise();

      if (response) {
        if (
          response.status >= 300 &&
          response.status < 400 &&
          response.headers.has('Location')
        ) {
          const redirectUrl = response.headers.get('Location');
          if (redirectUrl) {
            window.location.href = redirectUrl;
          }
        } else {
          const messageContainer = document.getElementById('div');
          if (messageContainer && response.body) {
            messageContainer.innerHTML = response.body.toString();
          }
          console.log(response);
        }
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }

  fetchAddFriendDiv(): void {
    this.addFriendShow = true;
    this.addFriendButtonShow = true;
  }

  addFriend(): void {
    const addFriendName = (
      document.getElementById('addFriendName') as HTMLInputElement
    ).value;
    const data = new HttpParams().set('userName', addFriendName);
    this.http
      .post<string>(
        'http://localhost:8080/BankingZoho/html/FriendRequest',
        data,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      )
      .subscribe(
        (response) => {
          this.responseMessage = response;
        },
        (error) => {
          console.error('Error during POST request:', error);
          this.responseMessage = 'An error occurred while sending request.';
        }
      );
  }

  fetchFriends(): void {
    this.http
      .get<string>('http://localhost:8080/BankingZoho/html/Friend', {
        responseType: 'text' as 'json',
      })
      .subscribe(
        (response) => {
          const selectElement = document.createElement('select');
          selectElement.id = 'friendList';

          if (response === 'null') {
            const optionElement = document.createElement('option');
            optionElement.textContent = 'No friends available';
            selectElement.appendChild(optionElement);
          } else {
            const optionElement = document.createElement('option');
            optionElement.textContent = 'Your friends';
            selectElement.appendChild(optionElement);
            const finalResult = response.slice(1, response.length - 1);
            const array = finalResult
              .split(',')
              .map((user) => user.trim().replace(/\]$/, ''));
            const options = [...new Set(array)];

            options.forEach((optionText) => {
              const optionElement = document.createElement('option');
              optionElement.value = optionText;
              optionElement.textContent = optionText;
              selectElement.appendChild(optionElement);
            });
          }

          const friendsDropDown = document.getElementById('friendsDropDown');
          if (friendsDropDown) {
            friendsDropDown.style.display = 'block';
            friendsDropDown.appendChild(selectElement);

            const dropdown = selectElement;
            dropdown.addEventListener('change', () => {
              const mutualFriendsButton = document.getElementById(
                'mutualFriendsButton'
              ) as HTMLElement;
              const chatButton = document.getElementById(
                'chatButton'
              ) as HTMLElement;
              mutualFriendsButton.style.display = 'block';
              chatButton.style.display = 'block';

              mutualFriendsButton.onclick = () => {
                this.showMutualFriends(dropdown.value);
              };
              chatButton.onclick = () => {
                document.getElementById('chatContainer')!.style.display =
                  'block';
              };
            });
          }
        },
        (error) => {
          console.error('Error fetching friends', error);
        }
      );
  }

  showMutualFriends(username: string): void {
    const data = `userName=${encodeURIComponent(username)}`;
    this.http
      .post<string>(
        'http://localhost:8080/BankingZoho/html/Friend?mode=mutual',
        data,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      )
      .subscribe(
        (response) => {
          const result = response;
          const finalResult = result.slice(1, result.length - 1);
          const userArray = finalResult
            .split(',')
            .map((user) => user.trim().replace(/\]$/, ''));
          const uniqueArray = [...new Set(userArray)];

          const tableContainer = document.getElementById('div');
          if (!tableContainer) {
            console.error('Error: div element not found');
            return;
          }

          tableContainer.innerHTML = '';

          if (uniqueArray.length === 0) {
            tableContainer.innerHTML = 'No mutual friends found';
            return;
          }

          const table = document.createElement('table');
          table.style.width = '100%';
          table.style.borderCollapse = 'collapse';
          const headerRow = document.createElement('tr');
          const headerCell = document.createElement('th');
          headerCell.textContent = 'Mutual Friends';
          headerCell.style.border = '1px solid black';
          headerCell.style.padding = '8px';
          headerRow.appendChild(headerCell);
          table.appendChild(headerRow);
          uniqueArray.forEach((friend) => {
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.textContent = friend;
            cell.style.border = '1px solid black';
            cell.style.padding = '8px';
            row.appendChild(cell);
            table.appendChild(row);
          });
          tableContainer.appendChild(table);
        },
        (error) => {
          console.error('Error fetching mutual friends:', error);
          const tableContainer = document.getElementById('div');
          if (tableContainer) {
            tableContainer.innerHTML =
              'An error occurred while fetching mutual friends.';
          }
        }
      );
  }

  submitChat(): void {
    const chatInput = (document.getElementById('chatInput') as HTMLInputElement)
      .value;
    const dropdown = document.getElementById('friendList') as HTMLSelectElement;
    const recieverUserName = dropdown.value;
    console.log(recieverUserName);
    console.log(chatInput);
    if (chatInput.trim() === '') {
      alert('Please enter a message.');
      return;
    }
    const data = new HttpParams()
      .set('message', chatInput)
      .set('reciever', recieverUserName);
    console.log(data);
    this.http
      .post<string>('http://localhost:8080/BankingZoho/html/Message', data, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      })
      .subscribe(
        (response) => {
          this.responseMessage = response;
          (document.getElementById('chatInput') as HTMLInputElement).value = '';
          document.getElementById('chatContainer')!.style.display = 'none';
        },
        (error) => {
          console.error('Error during POST request:', error);
          this.responseMessage = 'An error occurred while sending request.';
        }
      );
  }

  showFriendRequest(): void {
    this.http
      .get<string>(
        'http://localhost:8080/BankingZoho/html/FriendRequest?mode=listFriendRequests'
      )
      .subscribe(
        (response) => {
          const result = response;
          const finalResult = result.slice(1, result.length - 1);
          const userArray = finalResult
            .split(',')
            .map((user) => user.trim().replace(/\]$/, ''));
          const uniqueUsers = [...new Set(userArray)];

          const tableContainer = document.getElementById('div');
          const mainContainer = document.getElementById('container');

          if (!tableContainer || !mainContainer) {
            console.error('Table container or main container not found.');
            return;
          }

          mainContainer.style.display = 'none';

          tableContainer.innerHTML = '';

          const table = document.createElement('table');
          table.style.border = '1px solid black';
          table.style.borderCollapse = 'collapse';
          table.style.width = '100%';
          table.style.textAlign = 'center';

          const headerRow = table.insertRow();
          const usernameHeader = headerRow.insertCell(0);
          usernameHeader.textContent = 'Username';
          usernameHeader.style.border = '1px solid black';
          usernameHeader.style.padding = '8px';

          const actionHeader = headerRow.insertCell(1);
          actionHeader.textContent = 'Action';
          actionHeader.style.border = '1px solid black';
          actionHeader.style.padding = '8px';

          uniqueUsers.forEach((username) => {
            const row = table.insertRow();
            const usernameCell = row.insertCell(0);
            usernameCell.textContent = username;
            usernameCell.style.border = '1px solid black';
            usernameCell.style.padding = '8px';
            const actionCell = row.insertCell(1);
            const acceptButton = document.createElement('button');
            acceptButton.textContent = 'Accept';
            acceptButton.style.padding = '4px 8px';
            acceptButton.style.cursor = 'pointer';
            acceptButton.onclick = () => this.acceptFriend(username);
            actionCell.appendChild(acceptButton);
          });
          tableContainer.appendChild(table);
        },
        (error) => {
          console.error('Error fetching friend requests:', error);
          const tableContainer = document.getElementById('div');
          if (tableContainer) {
            tableContainer.innerHTML =
              'An error occurred while fetching friend requests.';
          }
        }
      );
  }

  acceptFriend(username: string): void {
    const data = new HttpParams().set('userName', username);
    this.http
      .post<string>(
        'http://localhost:8080/BankingZoho/html/FriendRequest?mode=acceptFriend',
        data,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      )
      .subscribe(
        (result) => {
          const responseTxt = document.getElementById('responseTxt');
          if (responseTxt) {
            responseTxt.innerHTML = result;
          }
        },
        (error) => {
          console.error('Error accepting friend request:', error);
          const responseTxt = document.getElementById('responseTxt');
          if (responseTxt) {
            responseTxt.innerHTML =
              'An error occurred while accepting the friend request.';
          }
        }
      );
  }

  viewMessages(): void {
    this.http
      .get<any>('http://localhost:8080/BankingZoho/html/Message')
      .subscribe((result) => {
        const messageContainer = document.getElementById('div');
        messageContainer!.style.display = 'block';
        messageContainer!.innerHTML = '';
        const table = document.createElement('table');
        table.style.border = '1px solid black';
        table.style.borderCollapse = 'collapse';
        table.style.textAlign = 'center';
        table.style.width = '100%';
        const headerRow = table.insertRow();
        headerRow.style.border = '1px solid black';
        const headerUserName = headerRow.insertCell(0);
        const headerMessage = headerRow.insertCell(1);
        const headerDate = headerRow.insertCell(2);
        headerUserName.innerHTML = 'User Name';
        headerMessage.innerHTML = 'Message';
        headerDate.innerHTML = 'Date';
        headerUserName.style.border = '1px solid black';
        headerMessage.style.border = '1px solid black';
        headerDate.style.border = '1px solid black';
        for (let messageId in result) {
          let messageDetails = result[messageId];
          const row = table.insertRow();
          row.style.border = '1px solid black';
          const cellUserName = row.insertCell(0);
          const cellMessage = row.insertCell(1);
          const cellDate = row.insertCell(2);
          cellUserName.innerHTML = messageDetails.userName;
          cellMessage.innerHTML = messageDetails.message;
          cellDate.innerHTML = messageDetails.date;
        }
        messageContainer!.appendChild(table);
      });
  }

  async viewDetails() {
    try {
      const div = document.getElementById('div') as HTMLElement;
      const resultDiv = document.getElementById(
        'userDetailsDiv'
      ) as HTMLElement;

      if (!div || !resultDiv) {
        console.error('Required DOM elements are missing.');
        return;
      }

      div.style.display = 'none';
      console.log('div display style after hiding:', div.style.display);

      resultDiv.style.display = 'block';
      console.log(
        'resultDiv display style after showing:',
        resultDiv.style.display
      );

      const response = await this.http
        .get<string[]>('http://localhost:8080/BankingZoho/html/User?mode=self')
        .toPromise();

      console.log(response);
      if (!response || !Array.isArray(response)) {
        console.error('Invalid response format:', response);
        return;
      }

      const resultId = [
        'Name',
        'NickName',
        'DateOfBirth',
        'Aadhaar',
        'PanNumber',
        'PhoneNumber',
        'Address',
        'NomineeName',
        'AccountNumber',
        'AccountType',
        'Balance',
        'NetBanking',
      ];

      resultId.forEach((id, index) => {
        const element = document.getElementById(id);
        if (id === this.NickName) {
          this.NickName = response[index];
          return;
        }
        if (element) {
          console.log(`Element found for ID: ${id}`);
          element.textContent = response[index] || 'N/A';
        } else {
          console.warn(`Element with ID "${id}" not found in the DOM.`);
          console.log(document.body.innerHTML);
        }
      });
    } catch (error) {
      console.error('Error fetching user details:', error);
    }
  }

  changeNickName() {
    const div = document.getElementById('nickNameChangeDiv') as HTMLElement;
    div.style.display = 'block';
    const nickNameChangeSubmitDiv = document.getElementById(
      'nickNameChangeSubmitDiv'
    ) as HTMLElement;
    nickNameChangeSubmitDiv.style.display = 'none';
  }

  async submitNickName() {
    const data = new HttpParams().set('NickNameInput', this.NickNameInput);
    try {
      const div = document.getElementById('nickNameChangeDiv') as HTMLElement;
      div.style.display = 'none';
      const response = await this.http
        .post(
          'http://localhost:8080/BankingZoho/html/User?mode=updateSelf',
          data,
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        )
        .toPromise();
      const result = response as string;
      const nickNameChangeSubmitDiv = document.getElementById(
        'nickNameChangeSubmitDiv'
      ) as HTMLElement;
      this.NickName = this.NickNameInput;
      nickNameChangeSubmitDiv.style.display = 'block';
      nickNameChangeSubmitDiv.innerHTML = result;
    } catch (error) {
      console.error('Error updating nickname:', error);
    }
  }

  navigateTo(url: string) {
    window.location.href = url;
  }

  logout(): void {
    document.cookie =
      'userName=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/';
    this.router.navigate(['/login']);
  }
}
